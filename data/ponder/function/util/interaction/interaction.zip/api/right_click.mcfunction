function ponder:util/interaction/right_click/ with storage ponder:scene interaction.right_click
data remove storage ponder:scene interaction.right_click