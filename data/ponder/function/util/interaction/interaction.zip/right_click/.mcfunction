summon marker ~ ~ ~ {Tags:["ponder.interaction"]}
clone ~-1 ~-1 ~-1 ~1 ~1 ~1 0 0 -20

summon wind_charge 0 0.5 -20 {Motion:[0,-1,0]}

schedule function ponder:util/interaction/right_click/_ 2t