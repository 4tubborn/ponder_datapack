execute positioned as @n[type=marker,tag=ponder.interaction] run clone 0 0 -20 2 0 -18 ~-1 ~-1 ~-1
kill @n[type=marker,tag=ponder.interaction]